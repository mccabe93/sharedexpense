﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SharedExpenseManager
{
    public partial class RootForm : Form
    {
        public RootForm()
        {
            InitializeComponent();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (panel1.Controls.Contains(LoginInterface.Instance))
                return;
            panel1.Controls.Add(LoginInterface.Instance);
            panel1.BringToFront();

        }
    }
}
