﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SharedExpenseManager
{
    public partial class LoginInterface : UserControl
    {
        private static LoginInterface _instance;
        public static LoginInterface Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new LoginInterface();
                return _instance;
            }
        }

        private LoginInterface()
        {
            InitializeComponent();
        }
    }
}
